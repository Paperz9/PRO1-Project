package loopstemplate;

public class App {

	public static void main(String[] args) {
		Gui.launch(Gui.class);
	}
}
