package ex2ex3student;

import ex2ex3.Person;

public class PersonTester {

    public static void main(String[] args) {
        // Ex. 2
        ex2ex3.Person p1 = new Person("Ib", 2000, 10, 6);
        p1.printPerson();

    }
}
